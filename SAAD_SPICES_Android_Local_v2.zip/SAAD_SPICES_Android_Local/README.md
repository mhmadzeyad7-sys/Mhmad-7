# SAAD SPICES Android

تطبيق مندوب مبيعات SAAD SPICES.

## الميزات الجديدة
- تسجيل حساب بالبريد الإلكتروني وكلمة مرور عبر Firebase Authentication.
- حفظ واستعادة بيانات الماركتات والتشييكات والفواتير والدفعات عبر Cloud Firestore.
- تحديد سعر موحد للقطعة.
- الفاتورة تحسب تلقائياً: عدد القطع × سعر القطعة.
- إرفاق صورة الفاتورة الورقية؛ تحفظ في Firebase Storage عند تسجيل الدخول.
- أيقونة خضراء مكتوب عليها SAAD بالأبيض.
- التنبيه قبل موعد التشييك بيوم.

## إعداد Firebase (مرة واحدة)
1. أنشئ مشروعاً في Firebase Console.
2. فعّل Authentication > Sign-in method > Email/Password.
3. أنشئ Firestore Database.
4. أنشئ Storage.
5. أنشئ Web App في إعدادات المشروع وانسخ الإعدادات إلى:
   `app/src/main/assets/firebase-config.js`
6. ضع قواعد Firestore وStorage الموجودة في `firebase.rules.txt` و`storage.rules.txt`.

بدون Firebase يمكن تشغيل التطبيق محلياً، لكن البيانات لن تستعاد بعد حذف التطبيق.
