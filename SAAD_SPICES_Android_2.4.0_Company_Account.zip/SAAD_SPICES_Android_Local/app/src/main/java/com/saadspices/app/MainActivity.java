package com.saadspices.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.net.Uri;
import android.os.Environment;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends FragmentActivity {
    public static final String CHANNEL_ID = "saad_spices_reminders";
    private static final String PREFS = "saad_spices";
    private static final String BIOMETRIC_ENABLED = "biometric_enabled";
    private static final int NOTIFICATION_PERMISSION = 1001;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 2001;
    private static final int LOCATION_PERMISSION_REQUEST = 3001;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        webView = new WebView(this);
        setContentView(webView);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternalUrl(url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                return openExternalUrl(request.getUrl().toString());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, android.webkit.GeolocationPermissions.Callback callback) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION_REQUEST);
                }
                callback.invoke(origin, true, false);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                    fallback.addCategory(Intent.CATEGORY_OPENABLE);
                    fallback.setType("image/*");
                    startActivityForResult(fallback, FILE_CHOOSER_REQUEST);
                }
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(this), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean openExternalUrl(String url) {
        if (url == null) return false;
        if (url.startsWith("file:") || url.startsWith("about:")) return false;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح الخرائط على الجهاز", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    public void requestLocationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            boolean fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            boolean coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            if (!fine && !coarse) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION_REQUEST);
            } else {
                webView.evaluateJavascript("window.__retryGeo && window.__retryGeo();", null);
            }
        } else {
            webView.evaluateJavascript("window.__retryGeo && window.__retryGeo();", null);
        }
    }

    public void openMap(String value) {
        try {
            Intent intent;
            if (value != null && value.matches("^-?\\d+(\\.\\d+)?,\\s*-?\\d+(\\.\\d+)?$")) {
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + value + "?q=" + Uri.encode(value)));
            } else {
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(value == null ? "" : value)));
            }
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "لا يوجد تطبيق خرائط متاح", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST && webView != null) {
            boolean granted = false;
            for (int r : grantResults) if (r == PackageManager.PERMISSION_GRANTED) { granted = true; break; }
            if (granted) webView.evaluateJavascript("window.__retryGeo && window.__retryGeo();", null);
            else Toast.makeText(this, "اسمح للتطبيق بالوصول إلى الموقع لتحديد موقع الماركت", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
                else if (data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                    results = new Uri[]{data.getClipData().getItemAt(0).getUri()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "تذكيرات SAAD SPICES", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("تنبيهات موعد تشييك الماركتات");
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }


    public boolean isBiometricAvailable() {
        BiometricManager bm = BiometricManager.from(this);
        int r = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
        return r == BiometricManager.BIOMETRIC_SUCCESS;
    }

    public boolean isBiometricEnabled() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(BIOMETRIC_ENABLED, false);
    }

    public void setBiometricEnabled(boolean enabled) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(BIOMETRIC_ENABLED, enabled).apply();
    }

    public void authenticateBiometric() {
        if (!isBiometricAvailable()) {
            Toast.makeText(this, "لا توجد بصمة إصبع أو بصمة وجه مسجلة على الجهاز", Toast.LENGTH_LONG).show();
            return;
        }
        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("فتح SAAD SPICES")
                .setSubtitle("استخدم بصمة الوجه أو الإصبع")
                .setNegativeButtonText("استخدام PIN")
                .build();
        BiometricPrompt prompt = new BiometricPrompt(this, ContextCompat.getMainExecutor(this),
                new BiometricPrompt.AuthenticationCallback() {
                    @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        runOnUiThread(() -> {
                            if (webView != null) webView.evaluateJavascript("window.__biometricUnlock && window.__biometricUnlock();", null);
                        });
                    }
                    @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                        // User can fall back to PIN; no destructive action here.
                    }
                    @Override public void onAuthenticationFailed() {
                        Toast.makeText(MainActivity.this, "لم يتم التحقق، حاول مرة أخرى", Toast.LENGTH_SHORT).show();
                    }
                });
        prompt.authenticate(promptInfo);
    }

    public void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
            } else Toast.makeText(this, "إشعارات SAAD SPICES مفعلة", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "إشعارات SAAD SPICES مفعلة", Toast.LENGTH_SHORT).show();
        }
    }

    public void syncStores(String json) {
        getSharedPreferences("saad_spices", MODE_PRIVATE).edit().putString("stores", json).apply();
        ReminderScheduler.scheduleAll(this, json);
    }

    public class AndroidBridge {
        private final Context context;
        AndroidBridge(Context context) { this.context = context; }
        @JavascriptInterface public void syncStores(String json) { MainActivity.this.syncStores(json); }
        @JavascriptInterface public void requestNotifications() { runOnUiThread(MainActivity.this::requestNotificationPermission); }
        @JavascriptInterface public void requestLocation() { runOnUiThread(MainActivity.this::requestLocationPermission); }
        @JavascriptInterface public void openMap(String value) { runOnUiThread(() -> MainActivity.this.openMap(value)); }
        @JavascriptInterface public boolean isBiometricAvailable() { return MainActivity.this.isBiometricAvailable(); }
        @JavascriptInterface public boolean isBiometricEnabled() { return MainActivity.this.isBiometricEnabled(); }
        @JavascriptInterface public void setBiometricEnabled(boolean enabled) { MainActivity.this.setBiometricEnabled(enabled); }
        @JavascriptInterface public void authenticateBiometric() { runOnUiThread(MainActivity.this::authenticateBiometric); }
    }
}
