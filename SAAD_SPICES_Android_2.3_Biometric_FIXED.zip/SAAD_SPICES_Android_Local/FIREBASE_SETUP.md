# SAAD SPICES – Firebase setup

Firebase Android configuration is included for package `com.saadspices.app` and project `saad-spices-m`.

## Map/location update – version 2.1.0
- Added Android location permissions and runtime permission request.
- Added a button when adding/editing a market to save the current GPS coordinates.
- Market coordinates are saved as `lat` and `lng` in the existing market record.
- Opening a market map now launches the device's external Maps application using saved coordinates when available.
- Existing markets without coordinates continue to use name/address search as a fallback.

## App security
Version 2.2 adds Android BiometricPrompt support. If the device supports enrolled biometrics, the user can enable biometric unlock. Android chooses the enrolled biometric modality supported by the device (for example face or fingerprint); the app never receives or stores biometric data.
