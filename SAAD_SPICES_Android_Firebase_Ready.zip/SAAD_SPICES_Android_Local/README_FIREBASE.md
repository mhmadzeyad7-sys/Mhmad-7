# SAAD SPICES - Firebase setup

The app is configured for Firebase project `saad-spices-m` and Android package `com.saadspices.app`.

## Firebase features used
- Email/password authentication
- Cloud Firestore for stores, checks, invoices and payments
- Firebase Storage for invoice photos

## Required Firebase console steps
1. Authentication > Sign-in providers > Email/Password: Enabled.
2. Firestore Database: created.
3. Storage: create/enable the Firebase Storage bucket.
4. Firestore Rules: paste the contents of `firestore.rules`.
5. Storage Rules: paste the contents of `storage.rules`.

The app uses the Firebase Web SDK inside its Android WebView. `firebase-config.js` contains the public Firebase client configuration for this project.
