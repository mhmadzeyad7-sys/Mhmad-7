// Firebase configuration for SAAD SPICES.
// These values are from the Firebase Android app registered as com.saadspices.app.
window.SAAD_FIREBASE_CONFIG = {
  apiKey: "AIzaSyC-sgatF8tyOoVHhvZcm2sq3rkKstbXyb0",
  authDomain: "saad-spices-m.firebaseapp.com",
  projectId: "saad-spices-m",
  storageBucket: "saad-spices-m.firebasestorage.app",
  appId: "1:228046950294:android:b3d5c78ad0930f69b697b7"
};
