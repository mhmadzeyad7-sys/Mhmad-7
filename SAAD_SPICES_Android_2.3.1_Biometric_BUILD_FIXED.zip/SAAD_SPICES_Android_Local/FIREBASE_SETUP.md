# SAAD SPICES – Firebase and biometric setup

Firebase Android configuration is included for package `com.saadspices.app` and project `saad-spices-m`.

Version 2.3.1 includes AndroidX Biometric support. The app uses Android system biometric authentication; it never receives or stores face/fingerprint data. PIN remains the fallback method.
