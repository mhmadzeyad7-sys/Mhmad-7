// This file is populated automatically by the GitHub Actions workflow
// when google-services.json is present in the repository.
window.SAAD_FIREBASE_CONFIG = {
  apiKey: "AIzaSyC-sgatF8tyOoVHhvZcm2sq3rkKstbXyb0",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "saad-spices-m",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "228046950294",
  appId: "1:228046950294:android:b3d5c78ad0930f69b697b7"
};
