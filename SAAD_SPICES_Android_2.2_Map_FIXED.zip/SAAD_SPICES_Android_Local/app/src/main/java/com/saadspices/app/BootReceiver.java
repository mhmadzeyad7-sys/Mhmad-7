package com.saadspices.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String stores = context.getSharedPreferences("saad_spices", Context.MODE_PRIVATE).getString("stores", "[]");
        ReminderScheduler.scheduleAll(context, stores);
    }
}
