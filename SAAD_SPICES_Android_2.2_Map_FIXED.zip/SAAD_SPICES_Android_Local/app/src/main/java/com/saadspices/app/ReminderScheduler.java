package com.saadspices.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class ReminderScheduler {
    private ReminderScheduler() {}

    public static void scheduleAll(Context context, String json) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        cancelAll(context, am);
        Map<String, ArrayList<String>> byDate = new HashMap<>();
        try {
            JSONArray stores = new JSONArray(json == null ? "[]" : json);
            for (int i=0; i<stores.length(); i++) {
                JSONObject s = stores.getJSONObject(i);
                String next = s.optString("nextCheck", "");
                String name = s.optString("name", "ماركت");
                if (next.isEmpty()) continue;
                Date nextDate = parseIso(next);
                if (nextDate == null) continue;
                Calendar reminder = Calendar.getInstance();
                reminder.setTime(nextDate);
                reminder.add(Calendar.DAY_OF_MONTH, -1);
                reminder.set(Calendar.HOUR_OF_DAY, 21);
                reminder.set(Calendar.MINUTE, 0);
                reminder.set(Calendar.SECOND, 0);
                reminder.set(Calendar.MILLISECOND, 0);
                if (reminder.getTimeInMillis() <= System.currentTimeMillis()) continue;
                String key = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(reminder.getTime());
                byDate.computeIfAbsent(key, k -> new ArrayList<>()).add(name);
            }
            for (Map.Entry<String, ArrayList<String>> e : byDate.entrySet()) {
                schedule(context, am, e.getKey(), e.getValue());
            }
        } catch (Exception ignored) {}
    }

    private static void schedule(Context context, AlarmManager am, String dateKey, ArrayList<String> names) throws Exception {
        Date d = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(dateKey + " 21:00");
        if (d == null || d.getTime() <= System.currentTimeMillis()) return;
        String body = "غداً موعد تشييك " + names.size() + " ماركت";
        if (names.size() <= 6) {
            StringBuilder sb = new StringBuilder(body).append(":\n");
            for (String n : names) sb.append("• ").append(n).append("\n");
            body = sb.toString().trim();
        }
        int id = Math.abs(dateKey.hashCode());
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("dateKey", dateKey);
        intent.putExtra("body", body);
        PendingIntent pi = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, d.getTime(), pi);
    }

    public static void cancelAll(Context context, AlarmManager am) {
        // Cancel alarms for a reasonable rolling window around today.
        Calendar c = Calendar.getInstance();
        for (int i=-7; i<=370; i++) {
            Calendar x = (Calendar)c.clone(); x.add(Calendar.DAY_OF_MONTH, i);
            String key = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(x.getTime());
            int id = Math.abs(key.hashCode());
            Intent intent = new Intent(context, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) { am.cancel(pi); pi.cancel(); }
        }
    }

    private static Date parseIso(String value) {
        try { return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).parse(value); } catch (Exception e) {
            try { return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).parse(value); } catch (Exception ignored) { return null; }
        }
    }
}
