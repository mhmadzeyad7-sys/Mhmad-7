# SAAD SPICES – Firebase setup

Firebase Android configuration has been added for package:
`com.saadspices.app`

Project:
`saad-spices-m`

The Android Firebase configuration is stored in:
`app/google-services.json`

For GitHub, do not commit Firebase Admin SDK service-account JSON files or private keys.
