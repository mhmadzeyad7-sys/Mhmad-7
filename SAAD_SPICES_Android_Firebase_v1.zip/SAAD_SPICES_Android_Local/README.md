# SAAD SPICES Android

تطبيق مندوب مبيعات SAAD SPICES.

## الميزات الجديدة
- تسجيل حساب بالبريد الإلكتروني وكلمة مرور عبر Firebase Authentication.
- حفظ واستعادة بيانات الماركتات والتشييكات والفواتير والدفعات عبر Cloud Firestore.
- تحديد سعر موحد للقطعة.
- الفاتورة تحسب تلقائياً: عدد القطع × سعر القطعة.
- إرفاق صورة الفاتورة الورقية؛ تحفظ في Firebase Storage عند تسجيل الدخول.
- أيقونة خضراء مكتوب عليها SAAD بالأبيض.
- التنبيه قبل موعد التشييك بيوم.

## إعداد Firebase (مرة واحدة)
1. أنشئ مشروعاً في Firebase Console.
2. فعّل Authentication > Sign-in method > Email/Password.
3. أنشئ Firestore Database.
4. أنشئ Storage.
5. أنشئ Web App في إعدادات المشروع وانسخ الإعدادات إلى:
   `app/src/main/assets/firebase-config.js`
6. ضع قواعد Firestore وStorage الموجودة في `firebase.rules.txt` و`storage.rules.txt`.

بدون Firebase يمكن تشغيل التطبيق محلياً، لكن البيانات لن تستعاد بعد حذف التطبيق.


### الإصدار 1.1
تم إصلاح اختيار صور الفواتير داخل Android WebView بإضافة منتقي صور أصلي لنظام Android.

## Firebase configuration
Firebase configuration is embedded for project `saad-spices-m` and package `com.saadspices.app`.
Email/Password authentication and Firestore sync are enabled in the app. Invoice images use Firebase Storage when available, with a compressed Firestore fallback if Storage upload is unavailable.
For production, replace Firestore/Storage test rules with authenticated-user rules.
